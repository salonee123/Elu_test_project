<style>
.center {
  margin-left: auto;
  margin-right: auto;
}
</style>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js
"></script>


<script type="text/javascript">
$(function () {

       var user_list =  $('#user_list').dataTable({
       
       pageLength : 5,

       lengthChange : false,

       processing: true,

       serverSide: true,

        "order": [[ 0, "desc" ]],

           "ajax":{

                "url": "{{url('/getUserList')}}",

                "dataType": "json",

                "type": "POST",

                "data":{ _token: "{{csrf_token()}}"}

               },

               "drawCallback": function (settings) { 

                var response = settings.json;

                $('.toggle-class').bootstrapToggle();

            },

         columns: [
                  { "data": "id", name: 'id',searchable: false},
                  { "data": "profile_pic", name: 'profile_pic',searchable: false},
                  { "data": "username" , name: 'username',searchable: false,"orderable": false},
                  { "data": "email" , name: 'email' ,"orderable": false,searchable: false}, 
                  { "data": "contact_number" , name: 'phone' ,"orderable": false,searchable: false}, 
                  { "data": "created_at" , name: 'created_at',"orderable": false },
                  { "data": "action" , name: 'action',"orderable": false,searchable: false},

        ],

        'createdRow': function( row, data, dataIndex ) {

            $(row).attr('id',"row"+data.id);

            $('td:eq(3)', row).attr( 'id',"toemail_"+data.id);

        },

    });

  })

</script>
<script type="text/javascript">
function delete_user(user_id){

  $.ajaxSetup({

    headers: {

      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

    }

  });

  $.ajax({

   type: 'POST',

   url: "<?php echo url('/delete_user'); ?>",

   enctype: 'multipart/form-data',

   data:{user_id:user_id,'_token':'<?php echo csrf_token(); ?>'},

     beforeSend:function(){

       return confirm("Are you sure you want to delete User?");

     },

     success: function(resultData) { 

       console.log(resultData);

       var obj = JSON.parse(resultData);

       if (obj.status == 'success') {

          $('#success_message').fadeIn().html(obj.msg);

          setTimeout(function() {

            $('#success_message').fadeOut("slow");

          }, 2000 );

          $("#row" + user_id).remove();

          setInterval('location.reload()', 2000);

       }

     },

     error: function(errorData) {

      console.log(errorData);

      alert('Please refresh page and try again!');

    }

  });

}
</script>

 <!-- Content Wrapper. Contains page content -->

  <div class="content-wrapper" style="padding:100px;">

    <!-- Content Header (Page header) -->

    <section class="content-header">
     <h1>Users List</h1>
    </section>

    <!-- Main content -->

    <section class="content">

      <p style="display: none;" id="success_message" class="alert alert-success"></p>

      @if ($errors->any())

      <div class="alert alert-danger">

       <ul>

         @foreach ($errors->all() as $error)

         <li>{{ $error }}</li>

         @endforeach

       </ul>

     </div>

     @endif

      @if (Session::has('error_arr'))

          <?php $error_arr = Session::get('error_arr'); ?>

          <div class="alert alert-info">

            <ul>

              <?php

              for($i=0; $i < count($error_arr); $i++){

                if(!empty($error_arr[$i])){

                  ?><li>{{$error_arr[$i]}}</li><?php

                }

              }

              ?>

            </ul>

          </div>

          <?php Session::forget('error_arr'); ?>

      @endif



     @if(Session::has('message'))

     <p class="alert {{ Session::get('alert-class', 'alert-success') }}">{{ Session::get('message') }}</p>

     @endif



     @if(Session::has('error'))

     <p class="alert {{ Session::get('alert-class', 'alert-danger') }}">{{ Session::get('error') }}</p>

     @endif

      <div class="row">

        <div class="col-xs-12">

          <div class="box">

            <div class="box-header">

             <div class ="row">

               <div class="col-md-6">

                <!--  <form action="{{ url('admin/UserImportData') }}" class="form-horizontal" method="POST" enctype="multipart/form-data">

            <input type="hidden" name="_token" value="{{ csrf_token() }}">

                    <div class="col-md-5">

                      <div class="form-group">

                        <input type="file" name="import_file" />

                      </div>

                    </div>

            <button class="btn btn-primary">Submit</button>

        </form> -->

               </div>

                <div class="col-md-12">

                   <h3 class="box-title pull-right btn-toolbar"><a href="{{ url('add_user') }}" class="btn btn-primary">Add User</a></h3>

                   <!-- <h3 class="box-title pull-right"><a class="btn btn-primary" href="{{ url('/admin/UserExportData') }}">Export User Data</a></h3> -->

                </div>

             </div>

            </div>

            <!-- /.box-header -->

            <div class="box-body">

              <table id="user_list" class="table table-bordered table-striped center">

                <thead>

                  <tr>

                    <th>S.No.</th>

                    <th>Image</th>

                    <th>Username</th>

                    <th>Email</th>

                    <th>Phone</th>

                    <th>Create Date</th>

                    <th>Action</th>

                  </tr>

                </thead>

                <tbody>

                </tbody>

              </table>

            </div>

            <!-- /.box-body -->

          </div>

          <!-- /.box -->

        </div>

        </div>

        <!-- /.col -->

      <!-- /.row -->

    </section>

    <!-- /.content -->

  </div>

  <!-- /.content-wrapper -->

  <!-- Modal -->


