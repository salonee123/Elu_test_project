
<style>
 td{
  text-align: center;
}
</style>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

<table id="dtBasicExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">

<h1>Product List</h1>
<?php if(Session::has('message')): ?>
<p class="alert <?php echo e(Session::get('alert-class', 'alert-success')); ?>"><?php echo e(Session::get('message')); ?></p>
<?php endif; ?>
<?php if(Session::has('error')): ?>
<p class="alert <?php echo e(Session::get('alert-class', 'alert-danger')); ?>"><?php echo e(Session::get('error')); ?></p>
<?php endif; ?>


<div class="box-header pull-right">
  <a href="<?php echo e(url('/addProduct')); ?>" class="btn btn-success" style="float: left">Add Product</a>
<div class="box-header pull-left">
<a href="<?php echo e(url('/user/dashboard')); ?>" class="btn btn-danger">Back </a>
</div>
  <thead>
    <tr>
      <th class="th-sm">Product Code </th>
      <th class="th-sm">Product Name</th>
      <th class="th-sm">Category Name</th>
      <th class="th-sm">Product Price</th>
      <th class="th-sm">QTY</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
  <?php if(!$product_details->isEmpty()): ?>
  <?php $i=1; ?>
  <?php $__currentLoopData = $product_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td><?php echo e($arr->product_code); ?></td>
    <td><?php echo e($arr->product_name); ?></td>
    <td><?php echo e($arr->category_name); ?></td>
    <td><?php echo e($arr->product_price); ?></td>
    <td><?php echo e($arr->qty); ?></td>
    <td>#</td>
  </tr>
  <?php $i++; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
  </tbody>
  <tfoot>
    <tr>
      <th>
        Product Code
      </th>
      <th>Product Name
      </th>
      <th>Category Name
      </th>
      <th>Product Price
      </th>
      <th>Product Qty
      </th>
      <th>Product Action
      </th>
      
    </tr>
  </tfoot>
</table>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css" />
<script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script>
  $(document).ready(function () {
  $('#dtBasicExample').DataTable();
  $('.dataTables_length').addClass('bs-select');
});
</script><?php /**PATH C:\xampp\htdocs\today_project\resources\views/productList.blade.php ENDPATH**/ ?>