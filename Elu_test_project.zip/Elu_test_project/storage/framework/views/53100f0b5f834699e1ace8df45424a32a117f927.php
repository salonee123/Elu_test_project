<!DOCTYPE html>
<html lang="en">
<head>
  <title>Add Order</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Add Order</h2>
  <form  method="post" action="<?php echo e(url('/submitOrder')); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
    <div class="form-group">
      <label for="email">Order Id :</label>
      <input type="text" class="form-control" id="order_id" placeholder="Enter Order Id" name="order_id">
    </div>
    <div class="form-group">
      <label for="pwd">Order Date:</label>
      <input type="text" class="form-control datepicker" id="datepicker" placeholder="Enter Order Date" name="order_date">
    </div>
    <div class="form-group">
      <label for="pwd">Order By</label>
      <?php
      $name = Auth::user()->name;
      ?>
      <input type="order_by" class="form-control" id="order_by" placeholder="Enter Order By" name="order_by" value="<?php echo e($name); ?>">
    </div>
    <div class="form-group">
      <label for="email">Order Amount:</label>
      <input type="text" class="form-control" id="order_amount" placeholder="Enter Order Amount" name="order_amount">
    </div>
    <div class="form-group">
      <label for="email">Product</label>
      <select id="lstFruits" name="product_id[]" multiple="multiple">Select Multiple Product
        <?php $__currentLoopData = $product_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($value->id); ?>"><?php echo e($value->product_name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </select>
    </div>
    <input  type="submit" name="submit" value="submit" class="btn btn-default">
  </form>
</div>

</body>
</html>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6/jquery.min.js" type="text/javascript"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js" type="text/javascript"></script>
<link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="Stylesheet" type="text/css" />
<script>
  $('.datepicker').datepicker({
    format: 'mm/dd/yyyy',
    startDate: '-3d'
});
</script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<link href="http://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.0.3/css/bootstrap.min.css"
    rel="stylesheet" type="text/css" />
<script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.0.3/js/bootstrap.min.js"></script>
<link href="http://cdn.rawgit.com/davidstutz/bootstrap-multiselect/master/dist/css/bootstrap-multiselect.css"
    rel="stylesheet" type="text/css" />
<script src="http://cdn.rawgit.com/davidstutz/bootstrap-multiselect/master/dist/js/bootstrap-multiselect.js"
    type="text/javascript"></script>
<script type="text/javascript">
    $(function () {
        $('#lstFruits').multiselect({
            includeSelectAllOption: true
        });
    });
</script>
<?php /**PATH C:\xampp\htdocs\today_project\resources\views/addOrder.blade.php ENDPATH**/ ?>