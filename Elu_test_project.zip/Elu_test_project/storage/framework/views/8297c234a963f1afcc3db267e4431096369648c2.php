<style>
 td{
  text-align: center;
}
</style>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

<table id="dtBasicExample" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
  
<h1>Order List</h1>
<div class="box-header pull-right">
  <a href="<?php echo e(url('/addOrder')); ?>" class="btn btn-success" style="float: left">Add Order</a>
<div class="box-header pull-left">
<a href="<?php echo e(url('/user/dashboard')); ?>" class="btn btn-danger">Back </a>
</div>
  <thead>
    <tr>
      <th class="th-sm">Order Id 

      </th>
      <th class="th-sm">Order Date

      </th>
      <th class="th-sm">Order By User

      </th>

      </th>
      <th class="th-sm">Order Value (Amount)
      </th>
      <th>Product Name</th>
    
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($value->order_id); ?></td>
    <td><?php echo e($value->order_date); ?></td>
    <td><?php echo e($value->order_by); ?></td>
    <td><?php echo e($value->order_amount); ?></td>
    <?php
    $product_id                 = $value->product_id;
    $product_arr                = explode(",", $product_id);
    $product_name               = array();
    foreach ($product_arr as $value) 
    {
      $product_name_details = DB::table('product')->where('id',  $value)->first();
      $product_name[]       = $product_name_details->product_name;
    }
      $product_name         = implode(",",  $product_name);                         

                
    ?>
    <td><?php echo e($product_name); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
  </tbody>
  
</table>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css" />
<script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script>
  $(document).ready(function () {
  $('#dtBasicExample').DataTable();
  $('.dataTables_length').addClass('bs-select');
});
</script><?php /**PATH C:\xampp\htdocs\today_project\resources\views/orderList.blade.php ENDPATH**/ ?>