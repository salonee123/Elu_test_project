<!DOCTYPE html>
<html lang="en">
<head>
  <title>Add Customer</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>

<div class="container">
  <h2>Add Customer</h2>
  <form  method="post" action="<?php echo e(url('/submitCustomer')); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
    <div class="form-group">
      <label for="email">Customer Name:</label>
      <input type="text" class="form-control" id="customer_name" placeholder="Enter Customer Name" name="customer_name">
    </div>
    <div class="form-group">
      <label for="pwd">Customer Address:</label>
      <input type="text" class="form-control" id="address" placeholder="Enter Customer Address" name="customer_address">
    </div>
    <input  type="submit" name="submit" value="submit" class="btn btn-default">
  </form>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\today_project\resources\views/addCustomer.blade.php ENDPATH**/ ?>