  <section>
        <!-- Left Sidebar -->
        <aside id="leftsidebar" class="sidebar">
            <!-- User Info -->
            <div class="user-info">
                <div class="image">
                    <img src="<?php echo e(url('resources/Admin')); ?>/images/user.png" width="48" height="48" alt="User" />
                </div>
                <div class="info-container">
                    <div class="name" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo e(Auth::user()->name); ?></div>
                    <div class="email"><?php echo e(Auth::user()->email); ?></div>
                    <div class="btn-group user-helper-dropdown">
                        <i class="material-icons" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">keyboard_arrow_down</i>
                        <ul class="dropdown-menu pull-right">
                            <li><a href="<?php echo e(url('admin/profile')); ?>/<?php echo e(Auth::user()->id); ?>"><i class="material-icons">person</i>Profile</a></li>
                            
                            <!-- <li role="separator" class="divider"></li> -->
                            <!-- <li><a href="<?php echo e(url('admin/logout')); ?>"><i class="material-icons">input</i>Logout</a></li> -->
                        </ul>
                    </div>
                </div>
            </div>
            <!-- #User Info -->
            <!-- Menu -->
            <div class="menu" id="myDIV">
                <ul class="list">
                    <li class="header">MAIN NAVIGATION</li>
                    <li <?php if(request()->segment(2)=='dashboard'){echo 'class="active"';} ?>>
                        <a href="<?php echo e(url('admin/dashboard')); ?>">
                            <i class="material-icons">home</i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                   <!--  <li <?php //if(request()->segment(2)=='university'){echo 'class="active"';} ?>>
                        <a href="<?php echo e(url('admin/university')); ?>">
                           <i class="material-icons">school</i>
                            <span>University</span>
                        </a>
                    </li> -->
                    <li <?php if(request()->segment(2)=='institution_list'){echo 'class="active"';} ?>>
                        <a href="<?php echo e(url('admin/institution_list')); ?>">
                            <i class="material-icons">text_fields</i>
                            <span>Institute</span>
                        </a>
                    </li>
                   <!--  <li <?php //if(request()->segment(2)=='campuse_list'){echo 'class="active"';} ?>>
                        <a href="<?php echo e(url('admin/campuse_list')); ?>">
                           <i class="material-icons">swap_calls</i>
                            <span>Campus</span>
                        </a>
                    </li> -->
                    <li <?php if(request()->segment(2)=='course_list'){echo 'class="active"';} ?>>
                        <a href="<?php echo e(url('admin/course_list')); ?>">
                            <i class="material-icons">layers</i>
                            <span>Course</span>
                        </a>
                    </li>
                    <li <?php if(request()->segment(2)=='degree_level'){echo 'class="active"';} ?>>
                        <a href="<?php echo e(url('admin/degree_level')); ?>">
                            <i class="material-icons">layers</i>
                            <span>Degree Level</span>
                        </a>
                    </li>
                    <li <?php if(request()->segment(2)=='course_category'){echo 'class="active"';} ?>>
                        <a href="<?php echo e(url('admin/course_category')); ?>">
                            <i class="material-icons">layers</i>
                            <span>Course Category</span>
                        </a>
                    </li>
                    <li <?php if(request()->segment(2)=='subject_area'){echo 'class="active"';} ?>>
                        <a href="<?php echo e(url('admin/subject_area')); ?>">
                            <i class="material-icons">layers</i>
                            <span>Subject Area</span>
                        </a>
                    </li>
                    
                    <li <?php if(request()->segment(2)=='destination'){echo 'class="active"';} ?>>
                        <a href="<?php echo e(url('admin/destination')); ?>">
                           <i class="material-icons">home_work</i>
                            <span>Destination</span>
                        </a>
                    </li>
                  <!--   <li <?php //if(request()->segment(2)=='scholarship'){echo 'class="active"';} ?>>
                        <a href="<?php echo e(url('admin/scholarship')); ?>">
                           <i class="material-icons">widgets</i>
                            <span>Scholarship</span>
                        </a>
                    </li> -->
                    <li <?php if(request()->segment(2)=='document'){echo 'class="active"';} ?>>
                        <a href="<?php echo e(url('admin/document')); ?>">
                           <i class="material-icons">widgets</i>
                            <span>Document Check List</span>
                        </a>
                    </li>
                    <li <?php if(request()->segment(2)=='inquiry'){echo 'class="active"';} ?>>
                        <a href="<?php echo e(url('admin/inquiry')); ?>">
                           <i class="material-icons">perm_device_information</i>
                            <span>Inquiry</span>
                        </a>
                    </li>
                     <li <?php if(request()->segment(2)=='client'){echo 'class="active"';} ?>>
                        <a href="<?php echo e(url('admin/client')); ?>">
                           <i class="material-icons">supervised_user_circle</i>
                            <span>Client</span>
                        </a>
                    </li>

                     <li <?php if(request()->segment(2)=='blogs'){echo 'class="active"';} ?>>
                        <a href="<?php echo e(url('admin/blogs')); ?>">
                           <i class="material-icons">widgets</i>
                            <span>Blog</span>
                        </a>
                    </li>
                    <?php if(Auth::user()->user_role=='1'): ?> 
                    <li <?php if(request()->segment(2)=='user'){echo 'class="active"';} ?>>
                        <a href="<?php echo e(url('admin/user')); ?>">
                           <i class="material-icons">supervised_user_circle</i>
                            <span>Users</span>
                        </a>
                    </li>
                    <?php endif; ?>


                   <li <?php if(request()->segment(2)=='about_us' || request()->segment(2)=='contact' || request()->segment(2)=='country'){echo 'class="active"';} ?>>
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">settings</i>
                            <span>Setting</span>
                        </a>
                        <ul class="ml-menu">
                            <li <?php if(request()->segment(2)=='about_us'){echo 'class="active"';} ?>>
                                <a href="<?php echo e(url('admin/about_us')); ?>">About Us </a>
                            </li> 
                             <li <?php if(request()->segment(2)=='contact'){echo 'class="active"';} ?>>
                                <a href="<?php echo e(url('admin/contact')); ?>">Contact user List </a>
                            </li>
                            <li <?php if(request()->segment(2)=='country'){echo 'class="active"';} ?>>
                                <a href="<?php echo e(url('admin/country')); ?>">Country List </a>
                            </li> 
                            <li <?php if(request()->segment(2)=='cms_page_list'){echo 'class="active"';} ?>>
                                <a href="<?php echo e(url('admin/cms_page_list')); ?>">CMS Page List </a>
                            </li>          
                        </ul>
                    </li>
                   <!--  <li>
                        <a href="" class="menu-toggle">
                            <i class="material-icons">swap_calls</i>
                            <span>Addmission Requirment</span>
                        </a>
                       
                    </li>
                    <li>
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">assignment</i>
                            <span>Notes</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="pages/forms/basic-form-elements.html">Basic Form Elements</a>
                            </li>
                            
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">view_list</i>
                            <span>Other</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="<?php echo e(url('admin/contact')); ?>">Contact user list </a>
                            </li>
                           
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">perm_media</i>
                            <span>Assignments</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="pages/medias/image-gallery.html">Image Gallery</a>
                            </li>
                            <li>
                                <a href="pages/medias/carousel.html">Carousel</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">pie_chart</i>
                            <span>Clients</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="pages/charts/morris.html">Morris</a>
                            </li>
                            <li>
                                <a href="pages/charts/flot.html">Flot</a>
                            </li>
                            <li>
                                <a href="pages/charts/chartjs.html">ChartJS</a>
                            </li>
                            <li>
                                <a href="pages/charts/sparkline.html">Sparkline</a>
                            </li>
                            <li>
                                <a href="pages/charts/jquery-knob.html">Jquery Knob</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">content_copy</i>
                            <span>Example Pages</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="pages/examples/profile.html">Profile</a>
                            </li>
                            <li>
                                <a href="pages/examples/sign-in.html">Sign In</a>
                            </li>
                            <li>
                                <a href="pages/examples/sign-up.html">Sign Up</a>
                            </li>
                            <li>
                                <a href="pages/examples/forgot-password.html">Forgot Password</a>
                            </li>
                            <li>
                                <a href="pages/examples/blank.html">Blank Page</a>
                            </li>
                            <li>
                                <a href="pages/examples/404.html">404 - Not Found</a>
                            </li>
                            <li>
                                <a href="pages/examples/500.html">500 - Server Error</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">map</i>
                            <span>Maps</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="pages/maps/google.html">Google Map</a>
                            </li>
                            <li>
                                <a href="pages/maps/yandex.html">YandexMap</a>
                            </li>
                            <li>
                                <a href="pages/maps/jvectormap.html">jVectorMap</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">trending_down</i>
                            <span>Multi Level Menu</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="javascript:void(0);">
                                    <span>Menu Item</span>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0);">
                                    <span>Menu Item - 2</span>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:void(0);" class="menu-toggle">
                                    <span>Level - 2</span>
                                </a>
                                <ul class="ml-menu">
                                    <li>
                                        <a href="javascript:void(0);">
                                            <span>Menu Item</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:void(0);" class="menu-toggle">
                                            <span>Level - 3</span>
                                        </a>
                                        <ul class="ml-menu">
                                            <li>
                                                <a href="javascript:void(0);">
                                                    <span>Level - 4</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="pages/changelogs.html">
                            <i class="material-icons">update</i>
                            <span>Profile</span>
                        </a>
                    </li>
                     -->
                </ul>
            </div>
            <!-- #Menu -->
            <!-- Footer -->
            <div class="legal">
                <div class="copyright">
                   Study in Australia Copyright ©<script>document.write(new Date().getFullYear());</script> 
                </div>
                <div class="version">
                    All Rights Reserved.
                </div>
            </div>
            <!-- #Footer -->
        </aside>
        <!-- #END# Left Sidebar -->
        <!-- Right Sidebar -->
        
        <!-- #END# Right Sidebar -->
    </section>


<?php /**PATH C:\xampp\htdocs\unissoss\resources\views/Admin/sidebar.blade.php ENDPATH**/ ?>