 <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
          <div class="user-panel">
            <div class="pull-left image">
              <img src="assets/dist/img/user2-160x160.jpg" class="img-circle" alt="User Image" />
            </div>
            <div class="pull-left info">
              <p>Alexander Pierce</p>
              <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
          </div>
          <!-- search form -->
         
          <!-- /.search form -->
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header">MAIN NAVIGATION</li>
            <li class="active treeview">
              <a href="user_list">
               <i class="fa fa-cutlery" aria-hidden="true"></i>
                <span>User List</span>
                <span class="label label-primary pull-right"></span>
              </a>
            </li>
            <li class="active treeview">
              <a href="admin/driver">
                <i class="fa fa-taxi"></i>
                <span>Driver List</span>
                <span class="label label-primary pull-right"></span>
              </a>
            </li>
            <li class="active treeview">
              <a href="admin/parcel">
                <i class="fa fa-gift"></i>
                <span>Parcel List</span>
                <span class="label label-primary pull-right"></span>
              </a>
            </li>
            <li class="active reeview">
              <a href="admin/trip">
                <i class="fa fa-plane"></i>
                <span>Trip List</span>
                <span class="label label-primary pull-right"></span>
              </a>
            </li>
            <li class="active reeview">
              <a href="admin/message/liveLocation">
                <i class="fa fa-map-marker"></i>
                <span>Live Location</span>
                <span class="label label-primary pull-right"></span>
              </a>
            </li>
            <li class="active reeview">
              <a href="admin/message/message">
                <i class="fa fa-envelope-o"></i>
                <span>Message</span>
                <span class="label label-primary pull-right"></span>
              </a>
            </li>
           </ul>
        </section>
        <!-- /.sidebar -->
 </aside>

<?php /**PATH C:\xampp\htdocs\today_project\resources\views/Admin/layouts/sidebar.blade.php ENDPATH**/ ?>