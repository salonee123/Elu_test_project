<style>
  ul#menu li
{
    list-style: none;
    background: #e8eef4 url(images/arrow.png) 2% 50% no-repeat;
    border: 1px solid #b2b2b2;
    padding: 0;
    margin-top: 5px;
}

ul#menu li a
{

    font-weight: bold;
    text-decoration: none;
    line-height: 2.8em;
    padding-right:.5em;
    color: #696969;
    text-align : center;
    align:center;

}
</style>
<a href="<?php echo e(url('/')); ?>">Back To Login</a>
<ul id="menu">              
    <li><a href="<?php echo e(url('/orderList')); ?>">Order Listing</a></li>
    <li><a href="<?php echo e(url('/productList')); ?>">Product Listing </a></li>
    <li><a href="<?php echo e(url('/customerList')); ?>">Customer Listing</a></li>
</ul><?php /**PATH C:\xampp\htdocs\today_project\resources\views/dashboard.blade.php ENDPATH**/ ?>