  <section>
        <!-- Left Sidebar -->
        <aside id="leftsidebar" class="sidebar">
            <!-- User Info -->
            <div class="user-info">
                <div class="image">
                    <img src="<?php echo e(url('resources/Admin')); ?>/images/user.png" width="48" height="48" alt="User" />
                </div>
                <div class="info-container">
                    <div class="name" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo e(Auth::user()->name); ?></div>
                    <div class="email"><?php echo e(Auth::user()->email); ?></div>
                    <div class="btn-group user-helper-dropdown">
                        <i class="material-icons" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">keyboard_arrow_down</i>
                        <ul class="dropdown-menu pull-right">
                            <li><a href="<?php echo e(url('admin/profile')); ?>/<?php echo e(Auth::user()->id); ?>"><i class="material-icons">person</i>Profile</a></li>
                            
                            <!-- <li role="separator" class="divider"></li> -->
                            <!-- <li><a href="<?php echo e(url('admin/logout')); ?>"><i class="material-icons">input</i>Logout</a></li> -->
                        </ul>
                    </div>
                </div>
            </div>
            <!-- #User Info -->
            <!-- Menu -->
            <div class="menu" id="myDIV">
                <ul class="list">
                    <li class="header">MAIN NAVIGATION</li>
                    <li <?php if(request()->segment(2)=='dashboard'){echo 'class="active"';} ?>>
                        <a href="<?php echo e(url('admin/dashboard')); ?>">
                            <i class="material-icons">home</i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                 
                    <li <?php if(request()->segment(2)=='institution_list'){echo 'class="active"';} ?>>
                        <a href="<?php echo e(url('admin/institution_list')); ?>">
                            <i class="material-icons">text_fields</i>
                            <span>University</span>
                        </a>
                    </li>                 
                                   
                </ul>
            </div>
            <!-- #Menu -->
            <!-- Footer -->
            <div class="legal">
                <div class="copyright">
                 Unissoss Copyright ©<script>document.write(new Date().getFullYear());</script> 
                </div>
                <div class="version">
                   All Rights Reserved.
                </div>
            </div>
            <!-- #Footer -->
        </aside>
        <!-- #END# Left Sidebar -->
        <!-- Right Sidebar -->
        
        <!-- #END# Right Sidebar -->
    </section>


<?php /**PATH C:\xampp\htdocs\unissoss\resources\views/Admin/layouts/sidebar.blade.php ENDPATH**/ ?>