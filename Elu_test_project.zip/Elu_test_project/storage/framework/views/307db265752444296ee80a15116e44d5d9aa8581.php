<!DOCTYPE html>
<html>
  <?php echo $__env->make('Admin.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('Admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <body class="skin-blue sidebar-mini">
    <div class="wrapper">
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            User List
            <small>User List</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href=""><i class="fa fa-dashboard"></i> Home</a></li>
         </ol>
        </section>
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">User List</h3>
                  <div class="pull-right box-tools">
                  <a href="admin/driver/adddriver" class="btn btn-info btn-sm">Add New</a> 
                  </div>
                </div><!-- /.box-header -->
                <div class="box-body">
              
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>First Name</th>
                        <th>Mobile Number</th>
                        <th>Email</th>
                        <th>Address</th>
                        <th>Status</th>
                        <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                      <?php $i=0; ?>
                      <?php $__currentLoopData = $data['user_list']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php $i++;
                                              $status ='';
                                               if($v->status == 1){
                                                      $status = 'Active';
                                                 }else{
                                                   $status = 'Inactive';
                                                  }
                                             ?>             
                      
                        <tr>
                          <td><?php echo $v->first_name.' '.$v->last_name; ?></td>
                          <td><?php echo $v->mobileno; ?></td>
                          <td><?php echo $v->email; ?></td>
                          <td><?php echo $v->address; ?></td>
                          <td>
                            <?php 
                              if($v->status == '1')
                              { 
                                ?>
                                <button class="btn btn-success">Active</button>
                               <?php 
                              }
                              else
                              {
                                ?>
                                <button class="btn btn-info btn btn-danger">In Active</button>
                               <?php    
                              }
                              ?>
                          </td>
                          <td><a href="admin/driver/fullViewDriver/<?php echo $v->id; ?>" title="View"><i class="fa fa-eye fa-2x "></i></a>&nbsp;&nbsp;
                          <a href="admin/driver/adddriver/<?php echo $v->id; ?>" title="Edit"><i class="fa fa-edit fa-2x "></i></a>
                          <a class="confirm" onclick="return delete_driver('<?php echo $v->id;?>');"  title="Remove"><i class="fa fa-trash-o fa-2x text-danger" data-toggle="modal" data-target=".bs-example-modal-sm"></i></a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
                                  
            </tbody>
                    
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->

            </div><!-- /.col -->
            </div>
            </div>
          <!-- /.row -->
        </section><!-- /.content -->
   
    
  </body>
</html>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/4.4.0/bootbox.min.js
">
    
</script>
<script type="text/javascript">
    function delete_driver(driverid)
    {
          
          bootbox.confirm("Are you sure you want to delete Driver Details",function(confirmed)
          {            
            if(confirmed)
            {
                location.href="admin/driver/delete_driver/"+driverid;
            }
        });
    } 
</script>

<style>
    div#msg_div .content {
    height: auto !important;
    min-height: auto !important;
}
div#msg_div .col-xs-12 {
    padding-left: 0;
}
</style>
<?php /**PATH C:\xampp\htdocs\today_project\resources\views/Admin/user_list.blade.php ENDPATH**/ ?>