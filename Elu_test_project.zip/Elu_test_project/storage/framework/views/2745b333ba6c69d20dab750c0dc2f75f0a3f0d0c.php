  <nav class="navbar" style="background: #519dcf">
        <div class="container-fluid">
            <div class="navbar-header">
                <a href="javascript:void(0);" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false"></a>
                <a href="javascript:void(0);" class="bars"></a>
                <a class="navbar-brand" href="<?php echo e(url('/admin/dashboard')); ?>" class="text-white mb-0">
                    <img src="<?php echo e(url('/public/images/logo.png')); ?>" style="width: 47%;">
                </a>
            </div>
            <div class="collapse navbar-collapse" id="navbar-collapse">
                <ul class="nav navbar-nav navbar-right">
                    <!-- Call Search -->
                    <!-- <li><a href="javascript:void(0);" class="js-search" data-close="true"><i class="material-icons">search</i></a></li> -->
                    <!-- #END# Call Search -->
                    <!-- Notifications -->
                   
                    <!-- #END# Notifications -->
                    <!-- Tasks -->
                    
                    <!-- #END# Tasks -->
                    <li class="pull-right"><a href="<?php echo e(url('admin/logout')); ?>" class="js-right-sidebar" data-close="true">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav><?php /**PATH C:\xampp\htdocs\unissoss\resources\views/Admin/layouts/nav.blade.php ENDPATH**/ ?>