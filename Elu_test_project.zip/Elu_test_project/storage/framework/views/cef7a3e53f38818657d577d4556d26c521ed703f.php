
<style>
  .has-error
  {
    color:red;
  }
</style>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">


 <!-- Content Wrapper. Contains page content -->

  <div class="content-wrapper" style="padding-left:400px;">

    <!-- Content Header (Page header) -->

    <section class="content-header">

      <h1>Add User </h1>

     
    </section>

    <!-- Main content -->

    <section class="content">

      <?php if($message = Session::get('message')): ?>

       <div class="alert alert-success alert-block">  

        <button type="button" class="close" data-dismiss="alert">×</button> 

        <strong><?php echo e($message); ?></strong>

      </div>

      <?php endif; ?>

    

     <!-- Small boxes (Stat box) -->

      <div class="row">

        <div class="col-xs-12">

          <!-- SELECT2 EXAMPLE -->

        <div class="box box-default">

          <div class="box-header">

             <div class="box-tools pull-right">

                <a href="<?php echo e(url('user/dashboard')); ?>" class="btn btn-primary"><i class="fa fa-arrow-left"></i> Back </a>

            </div>

          </div>

          <!-- /.box-header -->

          <form action="<?php echo e(url('/submit_user')); ?>" id="UserForm" method="POST" enctype="multipart/form-data">

            <input type="hidden" name="_token" id="csrf-token" value="<?php echo e(csrf_token()); ?>" />

            <div class="box-body">

              <div class="row">

                <div class="col-md-12">

                  <div class="form-group">

                    <label>First Name</label>

                    <input type="text" class="form-control" name="first_name" placeholder="Enter First Name">

                    <?php if($errors->has('first_name')): ?>

                        <span class="help-block <?php echo e($errors->has('first_name') ? ' has-error' : ''); ?>">

                          <strong><?php echo e($errors->first('first_name')); ?></strong>

                        </span>

                    <?php endif; ?>

                  </div>

                  <!-- /.form-group -->

                  <div class="form-group">

                    <label>Last Name</label>

                    <input type="text" class="form-control" name="last_name" placeholder="Enter Last Name">

                    <?php if($errors->has('last_name')): ?>

                        <span class="help-block <?php echo e($errors->has('last_name') ? ' has-error' : ''); ?>">

                          <strong><?php echo e($errors->first('last_name')); ?></strong>

                        </span>

                    <?php endif; ?>

                  </div>

                  <!-- /.form-group -->

                  <div class="form-group">

                    <label>Email</label>

                    <input type="text" class="form-control" name="email" placeholder="Enter Email Address">

                    <?php if($errors->has('email')): ?>

                        <span class="help-block <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">

                          <strong><?php echo e($errors->first('email')); ?></strong>

                        </span>

                    <?php endif; ?>

                  </div>

                  <!-- /.form-group -->

                  <div class="form-group">

                    <label>Phone</label>

                    <input type="text" class="form-control" name="contact_number" value="" placeholder="Enter Contact Number">

                    <?php if($errors->has('contact_number')): ?>

                        <span class="help-block <?php echo e($errors->has('contact_number') ? ' has-error' : ''); ?>">

                          <strong><?php echo e($errors->first('contact_number')); ?></strong>

                        </span>

                    <?php endif; ?>

                  </div>

                  <!-- /.form-group -->

                  <div class="form-group">

                    <label>Password</label>

                    <input type="password" class="form-control" name="password"  placeholder="Enter Password">

                      <?php if($errors->has('password')): ?>

                        <span class="help-block <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">

                          <strong><?php echo e($errors->first('password')); ?></strong>

                        </span>

                    <?php endif; ?>

                  </div>

                     <div class="form-group">

                    <label> Confirm Password</label>

                    <input type="password" class="form-control" name="confirm_password"  placeholder="Enter Password">

                      <?php if($errors->has('confirm_password')): ?>

                        <span class="help-block <?php echo e($errors->has('confirm_password') ? ' has-error' : ''); ?>">

                          <strong><?php echo e($errors->first('confirm_password')); ?></strong>

                        </span>

                    <?php endif; ?>

                  </div>

                  <div class="form-group">

                    <label>User Image</label>

                    <input type="file" class="form-control" name="image"/>

                      <?php if($errors->has('image')): ?>

                        <span class="help-block <?php echo e($errors->has('image') ? ' has-error' : ''); ?>">

                          <strong><?php echo e($errors->first('image')); ?></strong>

                        </span>

                    <?php endif; ?>

                  </div>

        

                </div>

                <!-- /.col -->

              </div>

            </div>

            <div class="box-footer">

              <button type="submit" class="btn btn-primary">Submit</button>

            </div>

            <!-- /.row -->

          </form>

          </div>

          <!-- /.box-body -->

        </div>

        <!-- /.box -->

      </div>

      <!-- /.row -->



    </section>

    <!-- /.content -->

  </div>

  <!-- /.content-wrapper -->





<?php /**PATH C:\xampp\htdocs\today_project\resources\views/add_user.blade.php ENDPATH**/ ?>