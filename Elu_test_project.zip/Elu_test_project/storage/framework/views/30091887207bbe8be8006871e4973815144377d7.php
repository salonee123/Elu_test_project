<!DOCTYPE html>
<html lang="en">
<head>
  <title>Add Customer</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Add Product</h2>
  <form  method="post" action="<?php echo e(url('/submitProduct')); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
    <div class="form-group">
      <label for="email">Product Code :</label>
      <input type="text" class="form-control" id="product_code" placeholder="Enter Product Code" name="product_code">
    </div>
    <div class="form-group">1
      <label for="pwd">Product Name:</label>
      <input type="text" class="form-control" id="product_name" placeholder="Enter Product Name" name="product_name">
    </div>
    <div class="form-group">
      <label for="pwd">Qty:</label>
      <input type="number" class="form-control" id="qty" placeholder="Enter Product Qty" name="qty">
    </div>
    <div class="form-group">
      <label for="email">Category Name:</label>
      <input type="text" class="form-control" id="category_name" placeholder="Enter Category Name" name="category_name">
    </div>
    <div class="form-group">
      <label for="email">Product Price:</label>
      <input type="text" class="form-control" id="product_price" placeholder="Enter Product Price" name="product_price">
    </div>
    <input  type="submit" name="submit" value="submit" class="btn btn-default">
  </form>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\today_project\resources\views/addProduct.blade.php ENDPATH**/ ?>