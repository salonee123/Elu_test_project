<!DOCTYPE html>
<html>
<?php echo $__env->make('Admin.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body class="theme-red">
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Please wait...</p>
        </div>
    </div>
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <!-- Search Bar -->
    <div class="search-bar">
        <div class="search-icon">
            <i class="material-icons">search</i>
        </div>
        <input type="text" placeholder="START TYPING...">
        <div class="close-search">
            <i class="material-icons">close</i>
        </div>
    </div>
    <!-- #END# Search Bar -->
    <!-- Top Bar -->
   <?php echo $__env->make('Admin.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- #Top Bar -->
  <?php echo $__env->make('Admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <section class="content">
        <div class="container-fluid">
            
                <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                       
                          
                        <div class="body">
                            <form id="form_validation" action="<?php echo e(url('EditInstitute')); ?>" enctype="multipart/form-data" method="POST">
                              <?php echo csrf_field(); ?>

                              <h3><?php echo e($data['title']); ?></h3>
                              <?php $__currentLoopData = $data['institute']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="editinst">
                            <div class="header">
                            <h2><b><?php echo e($value[0]->institution_name); ?></b></h2>
                            </div>

                              <input type="hidden" name="institutions_id[]" value="<?php echo e($value[0]->institutions_id); ?>">
                                                          
                             <div class="row clearfix">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line">
                                            <input type="text" class="form-control" name="institution_name[]" value="<?php echo e($value[0]->institution_name); ?>" placeholder="Institute Name" id="institution_name" required>
                                            
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line">
                                          <input type="text" class="form-control" name="institution_link[]" value="<?php echo e($value[0]->institution_link); ?>" placeholder="Institute Link" required>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row clearfix">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line">
                                           <img src="<?php echo e(url('public')); ?>/images/institute/<?php echo e($value[0]->institution_logo); ?>" width="200" height="200" >
                                            <input type="file" class="form-control" name="institute_logo[]" multiple>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="form-line">
                                           <img src="<?php echo e(url('public')); ?>/images/banner/<?php echo e($value[0]->institution_banner); ?>" width="200" height="200" >
                                          
                                             <input type="file" class="form-control" name="institute_banner[]" value="<?php echo e($value[0]->institution_banner); ?>" multiple>
                                        </div>
                                    </div>
                                </div>
                            </div>
                          
                             

                            <div class="row clearfix">
                                  <div class="col-sm-6">         
                                     <label class="form-label">Street</label>
                                         <input type="text" class="form-control" name="institution_address[]" value="<?php echo e($value[0]->institution_address); ?>">                                     
                                </div>

                               

                                <div class="col-sm-6">                                     
                                     <label class="form-label">City</label>
                                         <input type="text" class="form-control" name="institute_city[]" value="<?php echo e($value[0]->institute_city); ?>">                                       
                                   
                                </div>


                                
                            </div>
							
                                <div class="row clearfix">
								  <div class="col-sm-6">                                     
                                   <label class="form-label">State</label>
                                    <select class="form-control" id="institute_state" name="institute_state[]" required="">
                                        <option value="">Select State</option>
                                         <?php $__currentLoopData = $data['state']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statename): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <option value="<?php echo e($statename->name); ?>" <?php if($value[0]->institute_state==$statename->name){ echo "selected";} ?>><?php echo e($statename->name); ?></option>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                             
                                    </select>
                                      
                                </div>
								
                                 <div class="col-sm-6">                                     
                                     <label class="form-label">Zip/Post Code</label>
                                         <input type="text" class="form-control" name="institute_postcode[]" value="<?php echo e($value[0]->institute_postcode); ?>" >
                                                                   
                                </div>

                              </div>
                            <div class="row clearfix">
                                <div class="col-sm-12">
                                    <div class="form-group form-float">
                                        <div class="form-line">
                                          <textarea type="text" name="description[]" class="form-control" rows="3" required=""><?php echo strip_tags($value[0]->description); ?></textarea>
                                           
                                            
                                        </div>
                                     </div>
                                  </div>
                                   <!--  <div class="col-sm-6">
                                    <div class="form-group form-float">
                                        <div class="form-line">
                                          <textarea type="text" name="institution_address[]" class="form-control" rows="3" required=""><?php echo $value[0]->institution_address; ?></textarea>
                                           
                                            <label class="form-label">Address</label>
                                        </div>
                                     </div>
                                  </div> -->
                            </div>

                          </div>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <input type="submit" value="Submit" name="submit" class="btn btn-primary waves-effect">
                            </form>
                        </div>
                      
                    </div>
                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->make('Admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\unissoss\resources\views/Admin/edit_bulk_institute.blade.php ENDPATH**/ ?>