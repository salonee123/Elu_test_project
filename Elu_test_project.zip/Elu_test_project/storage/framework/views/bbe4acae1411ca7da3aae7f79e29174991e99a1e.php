 <!DOCTYPE html>
<html>
<?php echo $__env->make('Admin.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body class="theme-red">
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Please wait...</p>
        </div>
    </div>
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <!-- Search Bar -->
    <div class="search-bar">
        <div class="search-icon">
            <i class="material-icons">search</i>
        </div>
        <input type="text" placeholder="START TYPING...">
        <div class="close-search">
            <i class="material-icons">close</i>
        </div>
    </div>
    <!-- #END# Search Bar -->
    <!-- Top Bar -->
   <?php echo $__env->make('Admin.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- #Top Bar -->
  <?php echo $__env->make('Admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <section class="content">
        <div class="container-fluid">
            
                <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2><?php echo e($data['title']); ?></h2>
                      
                        </div>
                        <div class="body">
                            <form id="form_validation" action="<?php echo e(url('institute_save')); ?>" enctype="multipart/form-data" method="POST">
                              <?php echo csrf_field(); ?>
                               
                            <div class="col-sm-6 ">
                                <div class="form-group form-float">
                                    <div class="form-line">
                                         <?php if($data['title']== "Add University"): ?>
                                        <input type="text" class="form-control" name="institute_name" id="institute_name" required>
                                         <?php else: ?>
                                         <input type="text" class="form-control" value="<?php echo e($data['institute_view']->institution_name); ?>" readonly="">
                                          <?php endif; ?>
                                        <label class="form-label">Institute Name</label>
                                        <?php if($errors->has("institute_name")): ?>
                                        <span class="invalid-feedback d-block" role="alert" style="color: red;">
                                        <strong><?php echo e($errors->first('institute_name')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                       </div> 
                                    </div>
                                </div>
                                <div class="col-sm-6 ">
                                <div class="form-group form-float">
                                    <div class="form-line">
                                          <?php if($data['title']== "Add University"): ?>
                                        <input type="text" class="form-control" name="institute_link" required>
                                         <?php else: ?>
                                         <input type="text" class="form-control" value="<?php echo e($data['institute_view']->institution_link); ?>" readonly="">
                                          <?php endif; ?>
                                        <label class="form-label">Institute link</label>
                                         <?php if($errors->has("institute_link")): ?>
                                        <span class="invalid-feedback d-block" role="alert" style="color: red;">
                                        <strong><?php echo e($errors->first('institute_link')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                </div>
                             <div class="row clearfix">
                                <div class="col-sm-6 ">
                                	<div class="form-group"> 
                                    <label class="form-label">Logo</label>
                                    <div class="form-line">
                                        <?php if($data['title']== "Add University"): ?>
                                        <input type="file" class="form-control" name="institute_logo" required="">
                                        <?php else: ?>
                                        <?php if(!empty($data['institute_view']->institution_logo)): ?>
                                             <img src="<?php echo e(url('public')); ?>/images/institute/<?php echo e($data['institute_view']->institution_logo); ?>" width="200" height="200" >
                                         <?php else: ?>
                                            <img src="<?php echo e(url('resources/assets')); ?>/uploads/_logo.png" width="200" height="200" >
                                         <?php endif; ?>
                                         
                                         <?php endif; ?>
                                         <?php if($errors->has("institute_logo")): ?>
                                        <span class="invalid-feedback d-block" role="alert" style="color: red;">
                                        <strong><?php echo e($errors->first('institute_logo')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                   </div>
                                </div>
                                <div class="col-sm-6 ">
                                	<div class="form-group"> 
                                    <label class="form-label">Banner</label>
                                    <div class="form-line">
                                         <?php if($data['title']== "Add University"): ?>
                                        <input type="file" class="form-control" name="institute_banner" required="">
                                          <?php else: ?>
                                           <?php if(!empty($data['institute_view']->institution_logo)): ?>
                                            <img src="<?php echo e(url('public')); ?>/images/banner/<?php echo e($data['institute_view']->institution_banner); ?>" width="200" height="200" >
                                           <?php else: ?>
                                            <img src="<?php echo e(url('resources/assets')); ?>/images/institute/institude_banner.jpg" width="200" height="200" >
                                           <?php endif; ?>
                                         
                                           <?php endif; ?>
                                          <?php if($errors->has("institute_banner")): ?>
                                        <span class="invalid-feedback d-block" role="alert" style="color: red;">
                                        <strong><?php echo e($errors->first('institute_banner')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                   </div>
                                </div>
                            </div>
                               
                                
                                 
                                <label class="form-label">University Address</label>
                                <div class="row clearfix">
                                  <div class="col-sm-6"> 
                                  	<div class="form-group form-float">
                                  	<div class="form-line"> 
                                    <?php if($data['title']== "Add University"): ?>
                                    <label class="form-label">Street</label>
                                         <input type="text" class="form-control" value="" name="institution_address" required>
                                    <?php else: ?>
                                    <?php if(!empty($data['institute_view']->institution_address)): ?>
                                     <label class="form-label">Street</label>
                                         <input type="text" class="form-control" value="<?php echo e($data['institute_view']->institution_address); ?>" readonly="">
                                       
                                    <?php else: ?>
                                      <label class="form-label">Street</label>
                                        <input type="text" class="form-control" value="" readonly="">
                                        
                                    <?php endif; ?>
                                    
                                    <?php endif; ?>
                                     <?php if($errors->has("institution_address")): ?>
                                        <span class="invalid-feedback d-block" role="alert" style="color: red;">
                                        <strong><?php echo e($errors->first('institution_address')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                               

                                <div class="col-sm-6">
                                <div class="form-group form-float"> 
                                <div class="form-line"> 
                                    <?php if($data['title']== "Add University"): ?>
                                    <label class="form-label">City</label>
                                         <input type="text" class="form-control" value="" name="institute_city" required>
                                    <?php else: ?>
                                    <?php if(!empty($data['institute_view']->institute_city)): ?>
                                     <label class="form-label">City</label>
                                         <input type="text" class="form-control" value="<?php echo e($data['institute_view']->institute_city); ?>" readonly="">
                                       
                                    <?php else: ?>
                                      <label class="form-label">City</label>
                                        <input type="text" class="form-control" value="" readonly="">
                                        
                                    <?php endif; ?>
                                    
                                    <?php endif; ?>
                                     <?php if($errors->has("institute_city")): ?>
                                        <span class="invalid-feedback d-block" role="alert" style="color: red;">
                                        <strong><?php echo e($errors->first('institute_city')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                </div>
                            </div>
                        </div>                                
                            </div>
							
							
                             <div class="row clearfix">
								   <div class="col-sm-6">
                                 	<div class="form-group form-float forBtmBrdr"> 
                                      <?php if($data['title']== "Add University"): ?>
                                       <!-- <label class="form-label">State</label> -->
                                    <select class="form-control" id="institute_state" name="institute_state" required="">
                                        <option value="">Select State</option>
                                         <?php $__currentLoopData = $data['state']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statename): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <option value="<?php echo e($statename->name); ?>"><?php echo e($statename->name); ?></option>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                             
                                    </select>
                                      <?php else: ?>
                                       <label class="form-label">State</label>
                                         <input type="text" class="form-control" value="<?php echo e($data['institute_view']->institute_state); ?>" readonly="">
                                       
                                    
                                    <?php endif; ?>
                                     <?php if($errors->has("institute_state")): ?>
                                        <span class="invalid-feedback d-block" role="alert" style="color: red;">
                                        <strong><?php echo e($errors->first('institute_state')); ?></strong>
                                        </span>
                                     <?php endif; ?>
                                </div>
                            </div>
								
								
                                 <div class="col-sm-6"> 
                                 	<div class="form-group form-float">
                                 	<div class="form-line"> 
                                    <?php if($data['title']== "Add University"): ?>
                                    <label class="form-label">Zip/Post Code</label>
                                         <input type="text" class="form-control" value="" name="institute_postcode" required>
                                    <?php else: ?>
                                    <?php if(!empty($data['institute_view']->institute_postcode)): ?>
                                     <label class="form-label">Zip/Post Code</label>
                                         <input type="text" class="form-control" value="<?php echo e($data['institute_view']->institute_postcode); ?>" readonly="">
                                       
                                    <?php else: ?>
                                      <label class="form-label">Zip/Post Code</label>
                                        <input type="text" class="form-control" value="" readonly="">
                                        
                                    <?php endif; ?>
                                    
                                    <?php endif; ?>
                                     <?php if($errors->has("institute_postcode")): ?>
                                        <span class="invalid-feedback d-block" role="alert" style="color: red;">
                                        <strong><?php echo e($errors->first('institute_postcode')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                </div>

                            </div>
							
							
                             <div class="form-group form-float">
                                    <div class="form-line">
                                      
                                        <?php if($data['title']== "Add University"): ?>
                                        <textarea name="description" cols="30" rows="4" class="form-control no-resize" required></textarea>
                                          <?php else: ?>
											<?php echo $data['institute_view']->description; ?>

                                           <!-- <input type="" class="form-control" readonly="" value=" <?php echo $data['institute_view']->description; ?>"> -->
                                            <?php endif; ?>
                                        <!-- <label class="form-label">Description</label> -->
                                         <?php if($errors->has("description")): ?>
                                        <span class="invalid-feedback d-block" role="alert" style="color: red;">
                                        <strong><?php echo e($errors->first('description')); ?></strong>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                              <!--   <div class="form-group">
                                    <input type="checkbox" id="checkbox" name="checkbox">
                                    <label for="checkbox">I have read and accept the terms</label>
                                </div> -->
                                   <?php if($data['title']== "Add University"): ?>
                                <input type="submit" value="Submit" name="submit" class="btn btn-primary waves-effect">
                                <?php else: ?>
                                <a type="button" href="<?php echo e(url('admin/institution_list')); ?>"  class="btn btn-primary waves-effect">Back</a>
                                <?php endif; ?>
                                <!-- <button class="btn btn-primary waves-effect" name="submit" type="submit">SUBMIT</button> -->
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->make('Admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\unissoss\resources\views/Admin/add_institution.blade.php ENDPATH**/ ?>