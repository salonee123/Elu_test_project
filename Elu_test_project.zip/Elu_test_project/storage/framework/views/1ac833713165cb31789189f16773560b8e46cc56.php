<!DOCTYPE html>
<html>
<?php echo $__env->make('Admin.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body class="theme-red">
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Please wait...</p>
        </div>
    </div>
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <!-- Search Bar -->
    <div class="search-bar">
        <div class="search-icon">
            <i class="material-icons">search</i>
        </div>
        <input type="text" placeholder="START TYPING...">
        <div class="close-search">
            <i class="material-icons">close</i>
        </div>
    </div>
    <!-- #END# Search Bar -->
    <!-- Top Bar -->
   <?php echo $__env->make('Admin.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- #Top Bar -->
  <?php echo $__env->make('Admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <section class="content">
        <div class="container-fluid">
           
         
            <!-- #END# Basic Examples -->
            <!-- Exportable Table -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                       
                        <div class="header">
                              <?php if(Session::has('success')): ?>
                                <div class="alert alert-success" style="width: 80%; color: #8ec48e;"><?php echo e(Session::get('success')); ?></div>
                                <?php endif; ?>
                                <?php if(Session::has('warning')): ?>
                                 <div class="alert alert-danger"><?php echo e(Session::get('warning')); ?></div>
                                <?php endif; ?>
                            <h2>
                             University list
                            </h2>
                            
                            <ul class="header-dropdown m-r--5">
                              <!-- <form method="POST" id="form_validation" action="<?php echo e(url('institute/update')); ?>">  <?php echo csrf_field(); ?>
                                  <div id="edit_btn_show"> 
                                  <input type="submit" name="submit" value="Edit Institute" id="edit_institute"  class="btn bg-light-green waves-effect">
                                </div>
                                  <input type="hidden" id="hiddn_check_edit_institute" value="hiddn_check_edit_institute" name="institution_id">
                              </form> -->
                                <a href="<?php echo e(url('admin/add_institute')); ?>" type="button" class="btn btn-warning waves-effect">Add University</a>
                                <!-- <a href="<?php echo e(url('admin/institute_export')); ?>" type="button" class="btn btn-warning waves-effect">Export Institute</a> --> 
                               
                            </ul>
                        
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                    <thead>
                                        <tr>
                                            <th>S.No</th>
                                            <th>University Name</th>                                        
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                  
                                    <tbody>
                                    	 <?php $i=0; ?>
                                           <?php $__currentLoopData = $data['institute']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $i++;
                                                $status ='';
                                                 if($v->institution_status == 1){
                                                        $status = 'Active';
                                                   }else{
                                                     $status = 'Inactive';
                                                    }
                                               ?>
                                        <tr>
                                            <td><?php echo e($i); ?></td>
                                            <td><a href="<?php echo e(url('admin/details_institute')); ?>/<?php echo e($v->institutions_id); ?>"><?php echo e($v->institution_name); ?></a></td>
                                                                                    
                                            <td> <div class="switch">
                                           <label>
                                            <input type="checkbox"  onclick="return status_change('<?php echo e($v->institutions_id); ?>','<?php echo e($v->institution_status); ?>','/status_institute');"<?php if($status == 'Active'){ echo 'checked'; } ?> ><span class="lever switch-col-light-green"></span></label>
                                          </div>
                                          </td>
                                            <td>                                           
                                            <label for="<?php echo e($v->institutions_id); ?>"></label>
                                              <ul class="header-dropdown m-r--5 manegDots">
                                                <li class="dropdown" style="list-style: none;">
                                                  <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true">
                                                  <i class="material-icons">more_vert</i>
                                                  </a>
                                                  <ul class="dropdown-menu pull-right">
                                                    <li><a href="<?php echo e(url('institute/update')); ?>/<?php echo e($v->institutions_id); ?>" class=" waves-effect waves-block">Edit</a></li>
                                                    <li><a href="<?php echo e(url('admin/view_institute')); ?>/<?php echo e($v->institutions_id); ?>" class=" waves-effect waves-block">View</a></li> 
                                                    <!-- <li><a href="javascript:void(0);"  onclick="deletecourse('<?php echo e($v->institutions_id); ?>','institute/delete')" class=" waves-effect waves-block">Delete</a></li> -->
                                                    
                                                  </ul>
                                                </li>
                                              </ul>
                                            </span>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Exportable Table -->
        </div>
    </section>
   <?php echo $__env->make('Admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\unissoss\resources\views/Admin/institution_list.blade.php ENDPATH**/ ?>