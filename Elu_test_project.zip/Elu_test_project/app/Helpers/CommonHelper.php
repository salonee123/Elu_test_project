<?php



//use App\User_notification;



use App\User;



use App\Site_lang_text;



use Twilio\Rest\Client;



use GuzzleHttp\Client as GuzzleClient;

use Illuminate\Support\Facades\Session;

use Illuminate\Http\Request;

// use DB;



/*************Function to create unique alphanumeric user name *************/







/*************Function to Send mail *************/



function send_mail($data){



    Mail::send('sendmail', $data, function($message)  use ($data){



    $message->from('votivephp.priyanka@gmail.com', 'Search Education Providers');



    $message->to($data['email'])



    ->subject($data['subject']);



    });



}



// function lefbar_study(){

// 	 $courselist = DB::select("SELECT count(course_name) as count, course_name FROM `tbl_course` LEFT JOIN tbl_institution on tbl_course.institution_id=tbl_institution.institutions_id WHERE course_status=1 AND course_deleted=1 AND institution_deleted=1 AND institution_status=1 GROUP BY course_name");

// 	 return $courselist;

// }

function lefbar_study(){

     $courselist = DB::select("SELECT count(course_name) as count, course_name, category_name FROM `tbl_course` LEFT JOIN tbl_institution on tbl_course.institution_id=tbl_institution.institutions_id  LEFT JOIN tbl_course_category on tbl_course.course_category_id=tbl_course_category.category_id LEFT JOIN tbl_fees on tbl_course.course_id=tbl_fees.course_id WHERE course_status=1 AND course_category_id!=0 AND course_deleted=1 AND institution_deleted=1 AND institution_status=1 AND fee_deleted=1 GROUP BY category_name");

     return $courselist;

}


function getcountry(){

	 $countries = DB::select("SELECT * FROM `countries` ORDER BY name");



	 return $countries;



}
function getinstitution(){
     $institute = DB::select("SELECT * FROM `tbl_institution` where institution_status=1 AND institution_deleted=1 ");
     return $institute;
}


function getstates(){
	 $stateslist = DB::select("SELECT * FROM `states` where country_id=13");
	 return $stateslist;
}

function lefbar_country(){

	 $countrylist = DB::select("SELECT campus_state,states.name as state_name,country_id,count(tbl_course.course_id) as count FROM `tbl_campuse` LEFT JOIN states on campus_state=id LEFT JOIN tbl_course on tbl_course.campuse_id=tbl_campuse.campus_id LEFT JOIN tbl_institution on tbl_course.institution_id=tbl_institution.institutions_id LEFT JOIN tbl_fees on tbl_course.course_id=tbl_fees.course_id WHERE course_status=1 AND course_deleted=1 AND institution_deleted=1 AND institution_status=1 AND fee_deleted=1 GROUP BY states.id");
	 return $countrylist;

}

function lefbar_degree_level(){

	 $degreelevel = DB::select("SELECT *, count(degree_level_id) as count FROM `tbl_degree_level` INNER JOIN tbl_course on degree_id=degree_level_id INNER JOIN tbl_institution on tbl_course.institution_id=tbl_institution.institutions_id LEFT JOIN tbl_fees on tbl_course.course_id=tbl_fees.course_id where degree_status=1 AND degree_deleted=1 AND course_status=1 AND course_deleted=1 AND institution_deleted=1 AND fee_deleted=1 AND institution_status=1 GROUP BY degree_level_id");

	 return $degreelevel;

}

function degree_level(){

     $degreelevel = DB::select("SELECT * FROM `tbl_degree_level`  where degree_status=1 AND degree_deleted=1 GROUP BY degree_name");

     return $degreelevel;

}


function phonecode(){

	 $phonecode = DB::select("SELECT * FROM `countrycode`");
	 return $phonecode;

}

function inquiry_status(){
	 $status = DB::select("SELECT * FROM `tbl_inquiry_status`");
	 return $status;
}

function get_university(){

	 $university = DB::select("SELECT * FROM `tbl_university` where university_status=1 AND university_deleted=1");

	 return $university;

}


function get_course_list(){
 $course_list = DB::select("SELECT * FROM `tbl_course` where course_status='1' AND course_deleted='1'");
	 return $course_list;
}

function get_pages(){

	$pages = DB::select("SELECT * FROM `tbl_content_pages` where page_status='1' AND page_deleted='1'");

	return $pages;

}
function datetime(){
	// if (!empty($_SERVER['HTTP_CLIENT_IP']))   
 //        {
 //        $ip_address = $_SERVER['HTTP_CLIENT_IP'];
 //        }
 //        //whether ip is from proxy
 //        elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))  
 //        {
 //        $ip_address = $_SERVER['HTTP_X_FORWARDED_FOR'];
 //        }
 //        //whether ip is from remote address
 //        else
 //        {
 //        $ip_address = $_SERVER['REMOTE_ADDR'];
 //        }

 //        $ipInfo = file_get_contents('http://ip-api.com/json/' . $ip_address);
 //        $ipInfo = json_decode($ipInfo);
 //        $timezone = $ipInfo->timezone;
       // date_default_timezone_set($timezone);
        return date('Y-m-d H:i:s');
}

function get_course_category(){
    $course_category_list = DB::select("SELECT * FROM `tbl_course_category` where category_status='1' AND category_deleted='1'");
     return $course_category_list;
}

function getdestination(){
     $destinationlist = DB::select("SELECT * FROM `tbl_destination` where destination_deleted=1 AND destination_status=1");
     return $destinationlist;
}

?>