<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request; 
use App\Http\Controllers\Controller; 
use App\User, Hash; 
use Illuminate\Support\Facades\Auth; 
use Validator, DB;
use Illuminate\Validation\Rule;
use Twilio\Rest\Client;
use Session;
use Helper; 

class UserController extends Controller 
{
public $successStatus = true;
public $failureStatus = false;
// @return \Illuminate\Http\Response

    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [ 
            //'email' => 'required|email',
            'email' => 'required', 
            'password' => 'required', 
        ],
        [
            'email.required' => "Email is required",
            'password.required' =>  "Password is required",
        ]
        );
        if ($validator->fails()) {
            $messages = $validator->messages();
            foreach ($messages->all() as $message)
            {   
                return response()->json(['status'=>$this->failureStatus,'msg'=>$message]);            
            }
        }
        $email = $request->email;
        $user = DB::table('users')->where('user_role', '!=', 1)
                ->where(function($query) use ($email){
                    $query->where('email', $email);
                })           
                ->first();
            if(!empty($user)){
            $credentials = array(
                        'email'         => $user->email,
                        'password'      => $request->password,
                       
                    );          
            if (Auth::attempt($credentials))
            {
               
                
                $status = ''; 
                $msg = ''; 
               
                
                if(($user->status == 0)){
                    Auth::logout();
                    $status = $this->failureStatus; 
                    $msg = "Your profile is inactivate please contact to admin";  

                    session::flash('error', 'Your profile is inactivate please contact to admin');
                return redirect('/');                  
                }
                if (($user->status == 1)){
                    $user = Auth::user(); 
                    $status = $this->successStatus; 
                    $msg = Auth::user()->first_name. " Logged in successfully";
                }

                if(($user->status == 1) && ($user->is_verify_email== 0)){
                    $status = $this->successStatus; 
                    $msg = "Your account is not verify";                    
                }
                session::flash('error', 'Login in successfully');
                return redirect('user/dashboard');
            }
            else{


                session::flash('error', 'Email Id And Password Matched');
                return redirect('/');
            }
               
           
        }else{

             session::flash('error', 'User Not Exist');
             return redirect('/');
        }
    }

    public function userDashboard()
    {
        $user_id = Auth::user()->id;
        if(!empty($user_id))
        {
            return view('user_list');

        }
        else
        {
            session::flash('error', 'User Not Exist');
            return redirect('/');
        }

    }
    public function getUserList(Request $request)
    {

        

        $columns = array(0 =>'id', 

                         1 =>'profile_pic',
                         2 =>'full_name',
                         3=> 'username',
                         4=> 'email',
                         5=> 'status',
                         6=> 'created_at',
                         7=> 'action',

                        );

                        

                        

       $totalData = DB::table('users')

                    ->where('user_role',2)

                    ->count();

       $totalFiltered = $totalData; 



        $limit = $request->input('length');

        $start = $request->input('start');

        $order = $columns[$request->input('order.0.column')];

        $dir = $request->input('order.0.dir');

            

        if(empty($request->input('search.value'))){    



          $studentList = DB::table('users')


                        ->where('user_role',2)

                        ->offset($start)

                        ->limit($limit)

                        ->orderBy($order,$dir)

                        ->get();

        }else {

            $search = $request->input('search.value'); 

            $studentList =DB::table('users','')

                         ->where('user_role',2)

                         ->where(function ($query) use ($search) {

                                $query->where('first_name', 'LIKE',"%{$search}%")

                                ->orWhere('last_name', 'LIKE',"%{$search}%")
                                ->orWhere('email', 'LIKE',"%{$search}%")
                                ->orWhere('contact_number', 'LIKE',"%{$search}%");

                                // ->orWhere('grades.grade', 'LIKE',"%{$search}%");

                             })

                         ->offset($start)

                         ->limit($limit)

                         ->orderBy($order,$dir)

                         ->get();



            $totalFiltered = DB::table('users')

                            ->where('user_role',2)

                            ->where(function ($query) use ($search) {

                                $query->where('first_name', 'LIKE',"%{$search}%")

                                ->orWhere('last_name', 'LIKE',"%{$search}%")

                                // ->orWhere('username', 'LIKE',"%{$search}%")

                                ->orWhere('email', 'LIKE',"%{$search}%")

                                ->orWhere('contact_number', 'LIKE',"%{$search}%");

                                // ->orWhere('grades.grade', 'LIKE',"%{$search}%");

                             })

                            ->count();

        }                   

        $data = array();

        if (!empty($studentList)) {

           $i = $start+1;

            foreach ($studentList as $key => $value) {

            $checked =  ($value->status) ? 'checked' : '';

                

                $nestedData['id'] = $i;

                if(!empty($value->profile_pic))
                {

                   $nestedData['profile_pic'] = '<img src="'.url('/').'/public/uploads/profile_img/'. $value->profile_pic.'" style="width:100px;height:100px;">';
               }
               else{

                $nestedData['profile_pic'] = '<img src="'.url('/').'/public/uploads/profile_img/default.png" style="width:100px;height:100px;">';

               }
                $nestedData['full_name'] = $value->first_name." ".$value->last_name;

                $nestedData['username'] = $value->first_name." ".$value->last_name;

                $nestedData['email'] = !empty($value->email) ? $value->email : '' ;

                $nestedData['contact_number'] = !empty($value->contact_number) ? $value->contact_number : '' ;
                $nestedData['created_at'] = !empty($value->created_at) ? date('d-m-Y H:i A',strtotime($value->created_at)) : '' ;
                $nestedData['action'] ="<a href='".url('/edit_user/'.base64_encode($value->id))."'>Edit</a> | <a href='".url('/view_user/'.base64_encode($value->id))."'>View</a> |<a href='javascript:void(0)' onclick='delete_user(".$value->id.");'>Delete</a>";

                $i++;

                $data[] = $nestedData;

            }

         

        }

        

         $json_data = array(

                    "draw"            => intval($request->input('draw')),  

                    "recordsTotal"    => intval($totalData),  

                    "recordsFiltered" => intval($totalFiltered), 

                    "data"            => $data,  

                    );

            

        echo json_encode($json_data);           

        die;   

    }

    public function add_user()
    {
      return view('add_user');
    }

    public function submit_user(Request $request) 
    {



       $validator = Validator::make($request->all(), [

                    'first_name' => 'required',

                    'last_name' => 'required',

                    'email' => 'required|email|max:255|unique:users',

                    'password' => 'required|min:6',

                    'confirm_password' => 'required|same:password',

                    'contact_number' => 'required',


           ]);



        if ($validator->fails()) {

            return redirect('/add_user')->withErrors($validator)->withInput();

        } else {

            

            $name = $request->name;

            $first_name = $request->first_name;

            $email = $request->email;

            $password = $request->password;

            $last_name = $request->last_name;

            $name = $request->first_name.$request->last_name;

            if ($_FILES["image"]["name"]) {

            $userImage = time().'_'.$_FILES["image"]["name"];

            $Imgurl="public/uploads/profile_img/".time().'_'.$userImage;

            $name = $_FILES["image"]["name"];

            move_uploaded_file( $_FILES["image"]["tmp_name"], "public/uploads/profile_img/" .time().'_'.$_FILES['image']['name']);

            }else{

                $userImage='';

            }



            // $name_arr = explode(' ', $name);

            $obj = new User;

            $obj->first_name = $first_name;

            $obj->last_name = $last_name;

            $obj->name = $first_name.$last_name;

            $obj->email = $email;

            $obj->user_role = 2;
            
            $obj->password = bcrypt($password);

            $obj->temp_password = $password;

            $obj->contact_number =  $request->contact_number;

            $obj->profile_pic    =  $userImage;

            $obj->status = 1;

            $obj->created_at = date('Y-m-d H:i:s');

            $res = $obj->save();
            if ($res) {

                session::flash('message', 'User Added Succesfully.');

                return redirect('/user/dashboard');

            } else {

                session::flash('error', 'User records not inserted.');

                return redirect('/user/dashboard');

            }

        }

    }

    public function view_user(Request $request)
    {
        $user_id = base64_decode($request->id);
        $data['view_details'] = DB::table('users')->where('id', '=', $user_id)->first();
        return view('view_user')->with($data);
    }

    public function edit_user(Request $request)
    {

        $user_id = base64_decode($request->id);
        $data['edit_details'] = DB::table('users')->where('id', '=', $user_id)->first();
        return view('edit_user')->with($data);   
    }

    public function update_user(Request $request) 
    {

        
        $user_id        = $request->user_id;
        $first_name     = $request->first_name;
        $last_name      = $request->last_name;
        $contact_number = $request->contact_number;
        $email          = $request->email;
        $password       = $request->password;
        $temp_password  = $request->password;
        $name           = $first_name.$last_name;
        $where=array(['name', '=',$name]);
        if(!empty($user_id)){

                $where[]=['id','!=',$user_id];

        }

        $records = DB::table('users')->where($where)->get()->all();
        if(!empty($records)){

            session::flash('error', 'UserName already exist.');

            return redirect('edit_user/'. base64_encode($user_id));

        }else{


            $userData              = User::where('id', $user_id)->first();

            $userData->first_name  = $first_name;

            $userData->last_name   = $last_name;

            $userData->name        = $first_name.$last_name;

            if(!empty($password)){

              $userData->password = bcrypt($password);

              $userData->temp_password = $temp_password;  

            }

            if($_FILES["image"]["name"]) {

            $userImage = time().'_'.$_FILES["image"]["name"];

            $Imgurl="public/uploads/profile_img/".time().'_'.$userImage;

            $name = $_FILES["image"]["name"];

            move_uploaded_file( $_FILES["image"]["tmp_name"], "public/uploads/profile_img/" .time().'_'.$_FILES['image']['name']);

            $userData->profile_pic =$userImage;

            }
           
            $userData->contact_number = $contact_number;

            $userData->updated_at = date('Y-m-d H:i:s');

            $res = $userData->save();

            if ($res) {

                session::flash('message', 'User records updated succesfully.');
                return redirect('user/dashboard');

            } 
            else 
            {

                session::flash('error', 'Somthing went wrong.');
                return redirect('user/dashboard');

            }

        } 

    }

    public function delete_user(Request $request) 
    {
        $user_id = $request->user_id;

        $user_info = DB::table('users')->where('id', '=', $user_id)->first();

        $res = DB::table('users')->where('id', '=', $user_id)->delete();
        if ($res) 
        {
            return json_encode(array('status' => 'success', 'msg' => 'Data has been deleted successfully!'));

        } 
        else 
        {
            return json_encode(array('status' => 'error', 'msg' => 'Some internal issue occured.'));

        }

    }
   

    
}