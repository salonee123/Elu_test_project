<?php

namespace App\Http\Middleware;
use Auth;

use Closure;



class StatusMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
            

            if(Auth::user()->status == '1')
            {
               return $next($request);
            }
            if(Auth::user()->status == '0')
            {
                session::flash('error', 'User Not Active');
                return redirect('/');   

            }
        
    }
}