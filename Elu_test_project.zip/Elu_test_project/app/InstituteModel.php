<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InstituteModel extends Model
{
    protected $table = 'tbl_institution';
}
