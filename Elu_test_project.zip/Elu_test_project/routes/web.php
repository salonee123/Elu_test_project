<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('login');
});

Route::Post('/userlogin', 'UserController@login');
Route::get('/user/dashboard', 'UserController@userDashboard')->middleware('StatusMiddleware');
Route::POST('/getUserList', 'UserController@getUserList');
Route::get('/add_user', 'UserController@add_user');
Route::POST('/submit_user', 'UserController@submit_user');
Route::get('/view_user/{id}', 'UserController@view_user');
Route::get('/edit_user/{id}', 'UserController@edit_user');
Route::POST('/update_user', 'UserController@update_user');
Route::POST('/delete_user', 'UserController@delete_user');

















/*Admin Url Route*/



/* Course crud*/
